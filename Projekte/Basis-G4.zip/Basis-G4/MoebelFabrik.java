
/**
 * Beschreiben Sie hier die Klasse MoebelFabrik.
 * 
 * @author Tim Gabrikowski 
 * @version 18.02.2024
 */
public class MoebelFabrik
{
    public MoebelFabrik() {
        
    }
}
