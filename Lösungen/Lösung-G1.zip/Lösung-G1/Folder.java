
/**
 * Beschreiben Sie hier die Klasse File.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Folder extends DirEntry
{
  
    public Folder(String name) 
    {
        super(name);
    }
}
