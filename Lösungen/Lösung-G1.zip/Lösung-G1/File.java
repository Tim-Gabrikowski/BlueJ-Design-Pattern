
/**
 * Beschreiben Sie hier die Klasse File.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class File extends DirEntry
{
  
    public File(String name) 
    {
        super(name);
    }
}
